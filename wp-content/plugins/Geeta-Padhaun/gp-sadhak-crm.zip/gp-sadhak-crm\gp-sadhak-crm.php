<?php
/**
 * Plugin Name:       GP Sadhak CRM
 * Plugin URI:        https://example.com
 * Description:       Geeta Pariwar Nepal Sadhak CRM for WordPress. Manage sadhak (devotee) records, groups/levels, PRN lookup.
 * Version:           1.0.0
 * Author:            Geeta Pariwar Nepal
 * License:           GPL-2.0-or-later
 * Text Domain:       gp-sadhak-crm
 *
 * Usage: put the shortcode [gp_sadhak_crm] on any page (e.g. an Astra page).
 * The CRM reuses the same browser UI as the standalone app and talks to
 * WordPress REST API endpoints provided by this plugin.
 *
 * @package GP_Sadhak_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'GP_CRM_VERSION', '1.0.0' );
define( 'GP_CRM_PATH', plugin_dir_path( __FILE__ ) );
define( 'GP_CRM_URL', plugin_dir_url( __FILE__ ) );

require_once GP_CRM_PATH . 'includes/countries.php';
require_once GP_CRM_PATH . 'includes/db.php';
require_once GP_CRM_PATH . 'includes/auth.php';
require_once GP_CRM_PATH . 'includes/prn.php';
require_once GP_CRM_PATH . 'includes/api.php';
require_once GP_CRM_PATH . 'includes/import.php';
require_once GP_CRM_PATH . 'includes/admin.php';

register_activation_hook( __FILE__, 'gp_crm_activate' );

/**
 * Run on plugin activation: create tables and grant capabilities.
 */
function gp_crm_activate() {
	gp_crm_create_tables();
	gp_crm_add_capabilities();
}

/**
 * Enqueue plugin assets on pages containing the shortcode.
 */
add_action( 'wp_enqueue_scripts', 'gp_crm_enqueue_assets' );
function gp_crm_enqueue_assets() {
	global $post;
	if ( ! is_a( $post, 'WP_Post' ) || ! has_shortcode( $post->post_content, 'gp_sadhak_crm' ) ) {
		return;
	}

	wp_enqueue_style( 'gp-crm', GP_CRM_URL . 'assets/style.css', array(), GP_CRM_VERSION );
	wp_enqueue_script( 'gp-crm', GP_CRM_URL . 'assets/app.js', array(), GP_CRM_VERSION, true );

	// Pass the REST base + nonce so app.js can authenticate its API calls.
	wp_localize_script( 'gp-crm', 'gpCRM', array(
		'apiBase' => esc_url_raw( rest_url( 'gp_sadhak/v1' ) ),
		'nonce'   => wp_create_nonce( 'wp_rest' ),
	) );
}

/**
 * Shortcode: renders the CRM (login gate + dashboard).
 */
add_shortcode( 'gp_sadhak_crm', 'gp_crm_render_shortcode' );
function gp_crm_render_shortcode() {
	if ( ! is_user_logged_in() ) {
		$login = wp_login_url( get_permalink() );
		return '<div class="gp-crm-login-wrap"><p>Please <a href="'
			. esc_url( $login )
			. '">log in</a> to access the Sadhak CRM.</p></div>';
	}

	if ( ! gp_crm_can_access() ) {
		return '<div class="gp-crm-login-wrap"><p>You do not have permission to access the CRM. Contact your administrator.</p></div>';
	}

	ob_start();
	include GP_CRM_PATH . 'templates/dashboard.php';
	return ob_get_clean();
}
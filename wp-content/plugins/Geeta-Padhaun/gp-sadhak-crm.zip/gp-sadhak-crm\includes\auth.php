<?php
/**
 * Capabilities + WordPress user helpers.
 *
 * Capabilities:
 *   gp_access_sadhak  — use the CRM (view, add, edit)
 *   gp_manage_sadhak  — full admin (groups, delete, backup)
 * WordPress administrators always count as full admins.
 *
 * @package GP_Sadhak_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Current user may access the CRM.
 */
function gp_crm_can_access() {
	return is_user_logged_in() && ( current_user_can( 'gp_access_sadhak' ) || current_user_can( 'manage_options' ) );
}

/**
 * Current user may manage the CRM (groups, delete, backup).
 */
function gp_crm_can_manage() {
	return is_user_logged_in() && ( current_user_can( 'gp_manage_sadhak' ) || current_user_can( 'manage_options' ) );
}

/**
 * Grant capabilities to the built-in roles.
 */
function gp_crm_add_capabilities() {
	$role = get_role( 'administrator' );
	if ( $role ) {
		$role->add_cap( 'gp_access_sadhak' );
		$role->add_cap( 'gp_manage_sadhak' );
	}
	foreach ( array( 'editor', 'author', 'contributor' ) as $slug ) {
		$role = get_role( $slug );
		if ( $role ) {
			$role->add_cap( 'gp_access_sadhak' );
		}
	}
}

/**
 * Grant/revoke CRM capabilities for a specific user.
 */
function gp_crm_set_user_access( $user_id, $access, $manage = false ) {
	$user = get_userdata( $user_id );
	if ( ! $user ) {
		return;
	}
	if ( $access ) {
		$user->add_cap( 'gp_access_sadhak' );
	} else {
		$user->remove_cap( 'gp_access_sadhak' );
		$user->remove_cap( 'gp_manage_sadhak' );
	}
	if ( $manage ) {
		$user->add_cap( 'gp_manage_sadhak' );
	} else {
		$user->remove_cap( 'gp_manage_sadhak' );
	}
}

/**
 * Display names of all users (for the group role datalist).
 */
function gp_crm_user_names() {
	$names = array();
	$users = get_users( array( 'fields' => array( 'ID', 'display_name' ), 'orderby' => 'display_name', 'order' => 'ASC' ) );
	foreach ( $users as $u ) {
		$names[] = $u->display_name;
	}
	return $names;
}

/**
 * Map WP display_name => user ID.
 */
function gp_crm_name_to_id() {
	$map = array();
	$users = get_users( array( 'fields' => array( 'ID', 'display_name' ) ) );
	foreach ( $users as $u ) {
		$map[ $u->display_name ] = (int) $u->ID;
	}
	return $map;
}
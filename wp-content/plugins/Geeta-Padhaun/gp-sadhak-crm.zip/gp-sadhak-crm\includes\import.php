<?php
/**
 * One-time import from the standalone app's crm.db (SQLite) into
 * WordPress MySQL tables. Optionally creates WordPress users so the
 * CRM's staff accounts can log in with WordPress.
 *
 * @package GP_Sadhak_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Whether this server can read SQLite files (PDO sqlite driver).
 */
function gp_crm_sqlite_available() {
	return class_exists( 'PDO' ) && in_array( 'sqlite', PDO::getAvailableDrivers(), true );
}

/**
 * Perform the import. $file is the tmp path of an uploaded crm.db.
 *
 * @param string $file_path    Absolute path to the uploaded .db file.
 * @param bool   $create_users Whether to create WP users from CRM accounts.
 * @param int    $admin_user   WP user id to attribute unmapped records to.
 * @return array Result with 'success' and 'message' or 'error'.
 */
function gp_crm_import_from_sqlite( $file_path, $create_users = false, $admin_user = 0 ) {
	global $wpdb;

	if ( ! gp_crm_sqlite_available() ) {
		return array( 'success' => false, 'error' => 'SQLite (pdo_sqlite) is not available on this server, so the .db import cannot run.' );
	}
	if ( ! is_file( $file_path ) ) {
		return array( 'success' => false, 'error' => 'File not found.' );
	}

	try {
		$pdo = new PDO( 'sqlite:' . $file_path );
		$pdo->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );

		foreach ( array( 'groups', 'sadhak', 'sadhak_history', 'users' ) as $t ) {
			$check = $pdo->query( "SELECT name FROM sqlite_master WHERE type='table' AND name=" . $pdo->quote( $t ) )->fetch();
			if ( ! $check ) {
				return array( 'success' => false, 'error' => "Required table '$t' not found in the file. Is it a crm.db from the app?" );
			}
		}
	} catch ( Exception $e ) {
		return array( 'success' => false, 'error' => 'Not a valid SQLite database: ' . $e->getMessage() );
	}

	$prefix = $wpdb->prefix;

	// Optional: map CRM user ids -> WP user ids.
	$user_map = array();
	if ( $admin_user ) {
		$user_map[0] = $admin_user;
	}

	if ( $create_users ) {
		$created = 0;
		foreach ( $pdo->query( "SELECT id, full_name, username FROM users" ) as $u ) {
			$username = trim( $u['username'] );
			if ( '' === $username || 'admin' === $username ) {
				continue;
			}
			$existing = get_user_by( 'login', $username );
			if ( $existing ) {
				$user_map[ (int) $u['id'] ] = $existing->ID;
				continue;
			}
			$uid = wp_create_user( $username, wp_generate_password( 16, true, false ), $username . '@geetapariwar.invalid' );
			if ( is_wp_error( $uid ) || ! $uid ) {
				continue;
			}
			$wp_user = get_userdata( $uid );
			$wp_user->display_name = $u['full_name'] ? $u['full_name'] : $username;
			wp_update_user( $wp_user );
			$wp_user->add_cap( 'gp_access_sadhak' );
			$user_map[ (int) $u['id'] ] = $uid;
			$created++;
		}
		update_option( 'gp_crm_user_map', $user_map );
	}

	$map = function ( $id ) use ( $user_map, $admin_user ) {
		$id = (int) $id;
		return isset( $user_map[ $id ] ) ? $user_map[ $id ] : $admin_user;
	};

	$rows_groups = $pdo->query( 'SELECT * FROM groups' )->fetchAll( PDO::FETCH_ASSOC );
	$rows_sadhak = $pdo->query( 'SELECT * FROM sadhak' )->fetchAll( PDO::FETCH_ASSOC );
	$rows_hist   = $pdo->query( 'SELECT * FROM sadhak_history' )->fetchAll( PDO::FETCH_ASSOC );

	$wpdb->query( "DELETE FROM {$prefix}gp_sadhak_history" );
	$wpdb->query( "DELETE FROM {$prefix}gp_sadhak" );
	$wpdb->query( "DELETE FROM {$prefix}gp_groups" );

	foreach ( $rows_groups as $r ) {
		$wpdb->insert( $prefix . 'gp_groups', array(
			'id'        => $r['id'],
			'name'      => $r['name'],
			'bc_id'     => isset( $r['bc_id'] ) && $r['bc_id'] ? $map( $r['bc_id'] ) : null,
			'gc_id'     => isset( $r['gc_id'] ) && $r['gc_id'] ? $map( $r['gc_id'] ) : null,
			'ct_id'     => isset( $r['ct_id'] ) && $r['ct_id'] ? $map( $r['ct_id'] ) : null,
			'ta_id'     => isset( $r['ta_id'] ) && $r['ta_id'] ? $map( $r['ta_id'] ) : null,
			'bc_name'   => isset( $r['bc_name'] ) ? $r['bc_name'] : null,
			'gc_name'   => isset( $r['gc_name'] ) ? $r['gc_name'] : null,
			'ct_name'   => isset( $r['ct_name'] ) ? $r['ct_name'] : null,
			'ta_name'   => isset( $r['ta_name'] ) ? $r['ta_name'] : null,
			'timing'    => isset( $r['timing'] ) ? $r['timing'] : null,
			'zoom_link' => isset( $r['zoom_link'] ) ? $r['zoom_link'] : null,
			'level'     => isset( $r['level'] ) && $r['level'] ? $r['level'] : 'Level 1',
			'batch'     => isset( $r['batch'] ) && $r['batch'] ? $r['batch'] : 'Regular',
		) );
	}

	foreach ( $rows_sadhak as $r ) {
		$wpdb->insert( $prefix . 'gp_sadhak', array(
			'id'         => $r['id'],
			'name'       => $r['name'],
			'phone'      => $r['phone'],
			'email'      => isset( $r['email'] ) ? $r['email'] : null,
			'prn'        => isset( $r['prn'] ) ? $r['prn'] : null,
			'group_id'   => isset( $r['group_id'] ) && $r['group_id'] ? $r['group_id'] : null,
			'bc_name'    => isset( $r['bc_name'] ) ? $r['bc_name'] : null,
			'gc_name'    => isset( $r['gc_name'] ) ? $r['gc_name'] : null,
			'ct_name'    => isset( $r['ct_name'] ) ? $r['ct_name'] : null,
			'ta_name'    => isset( $r['ta_name'] ) ? $r['ta_name'] : null,
			'created_by' => isset( $r['created_by'] ) && $r['created_by'] ? $map( $r['created_by'] ) : $admin_user,
			'updated_by' => isset( $r['updated_by'] ) && $r['updated_by'] ? $map( $r['updated_by'] ) : $admin_user,
			'created_at' => isset( $r['created_at'] ) && $r['created_at'] ? $r['created_at'] : current_time( 'mysql' ),
			'updated_at' => isset( $r['updated_at'] ) && $r['updated_at'] ? $r['updated_at'] : current_time( 'mysql' ),
		) );
	}

	foreach ( $rows_hist as $r ) {
		$wpdb->insert( $prefix . 'gp_sadhak_history', array(
			'id'         => $r['id'],
			'sadhak_id'  => $r['sadhak_id'],
			'group_id'   => isset( $r['group_id'] ) && $r['group_id'] ? $r['group_id'] : null,
			'group_name' => isset( $r['group_name'] ) ? $r['group_name'] : null,
			'bc_name'    => isset( $r['bc_name'] ) ? $r['bc_name'] : null,
			'gc_name'    => isset( $r['gc_name'] ) ? $r['gc_name'] : null,
			'ct_name'    => isset( $r['ct_name'] ) ? $r['ct_name'] : null,
			'ta_name'    => isset( $r['ta_name'] ) ? $r['ta_name'] : null,
			'changed_by' => isset( $r['changed_by'] ) && $r['changed_by'] ? $map( $r['changed_by'] ) : $admin_user,
			'changed_at' => isset( $r['changed_at'] ) && $r['changed_at'] ? $r['changed_at'] : current_time( 'mysql' ),
		) );
	}

	$message = sprintf(
		'Import complete: %d groups, %d sadhaks, %d history rows.',
		count( $rows_groups ),
		count( $rows_sadhak ),
		count( $rows_hist )
	);
	if ( $create_users ) {
		$message .= isset( $created ) ? " Created $created WordPress users." : '';
	}

	return array( 'success' => true, 'message' => $message );
}
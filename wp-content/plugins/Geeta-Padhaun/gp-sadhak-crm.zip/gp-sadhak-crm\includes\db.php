<?php
/**
 * Database schema + CRUD helpers for the GP Sadhak CRM.
 * Mirrors the standalone app's SQLite schema using WordPress MySQL tables.
 *
 * Tables: {prefix}gp_groups, {prefix}gp_sadhak, {prefix}gp_sadhak_history
 *
 * @package GP_Sadhak_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Create/update the plugin tables.
 */
function gp_crm_create_tables() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';

	$charset = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE {$wpdb->prefix}gp_groups (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		name varchar(255) NOT NULL,
		bc_id bigint(20) unsigned DEFAULT NULL,
		gc_id bigint(20) unsigned DEFAULT NULL,
		ct_id bigint(20) unsigned DEFAULT NULL,
		ta_id bigint(20) unsigned DEFAULT NULL,
		bc_name varchar(255) DEFAULT NULL,
		gc_name varchar(255) DEFAULT NULL,
		ct_name varchar(255) DEFAULT NULL,
		ta_name varchar(255) DEFAULT NULL,
		timing varchar(255) DEFAULT NULL,
		zoom_link text,
		level varchar(50) DEFAULT 'Level 1',
		batch varchar(50) DEFAULT 'Regular',
		PRIMARY KEY  (id),
		UNIQUE KEY name (name)
	) $charset;

	CREATE TABLE {$wpdb->prefix}gp_sadhak (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		name varchar(255) NOT NULL,
		phone varchar(50) NOT NULL,
		email varchar(255) DEFAULT NULL,
		prn varchar(100) DEFAULT NULL,
		group_id bigint(20) unsigned DEFAULT NULL,
		bc_name varchar(255) DEFAULT NULL,
		gc_name varchar(255) DEFAULT NULL,
		ct_name varchar(255) DEFAULT NULL,
		ta_name varchar(255) DEFAULT NULL,
		created_by bigint(20) unsigned DEFAULT NULL,
		updated_by bigint(20) unsigned DEFAULT NULL,
		created_at datetime DEFAULT NULL,
		updated_at datetime DEFAULT NULL,
		PRIMARY KEY  (id),
		UNIQUE KEY phone (phone),
		KEY group_id (group_id)
	) $charset;

	CREATE TABLE {$wpdb->prefix}gp_sadhak_history (
		id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
		sadhak_id bigint(20) unsigned NOT NULL,
		group_id bigint(20) unsigned DEFAULT NULL,
		group_name varchar(255) DEFAULT NULL,
		bc_name varchar(255) DEFAULT NULL,
		gc_name varchar(255) DEFAULT NULL,
		ct_name varchar(255) DEFAULT NULL,
		ta_name varchar(255) DEFAULT NULL,
		changed_by bigint(20) unsigned DEFAULT NULL,
		changed_at datetime DEFAULT NULL,
		PRIMARY KEY  (id),
		KEY sadhak_id (sadhak_id)
	) $charset;";

	dbDelta( $sql );
}

/**
 * All groups as (id, name, level, batch).
 */
function gp_crm_get_groups() {
	global $wpdb;
	return $wpdb->get_results(
		"SELECT id, name, COALESCE(NULLIF(level,''), 'Level 1') AS level, COALESCE(NULLIF(batch,''), 'Regular') AS batch
		 FROM {$wpdb->prefix}gp_groups ORDER BY name ASC",
		ARRAY_A
	);
}

/**
 * A single group with resolved role-holder names.
 */
function gp_crm_get_group( $id ) {
	global $wpdb;
	return $wpdb->get_row( $wpdb->prepare(
		"SELECT g.id, g.name,
		        COALESCE(NULLIF(g.level,''), 'Level 1') AS level,
		        COALESCE(NULLIF(g.batch,''), 'Regular') AS batch,
		        COALESCE(NULLIF(g.bc_name,''), ubc.display_name, '') AS bc_name,
		        COALESCE(NULLIF(g.gc_name,''), ugc.display_name, '') AS gc_name,
		        COALESCE(NULLIF(g.ct_name,''), uct.display_name, '') AS ct_name,
		        COALESCE(NULLIF(g.ta_name,''), uta.display_name, '') AS ta_name,
		        COALESCE(g.timing, '') AS timing,
		        COALESCE(g.zoom_link, '') AS zoom_link
		 FROM {$wpdb->prefix}gp_groups g
		 LEFT JOIN {$wpdb->users} ubc ON ubc.ID = g.bc_id
		 LEFT JOIN {$wpdb->users} ugc ON ugc.ID = g.gc_id
		 LEFT JOIN {$wpdb->users} uct ON uct.ID = g.ct_id
		 LEFT JOIN {$wpdb->users} uta ON uta.ID = g.ta_id
		 WHERE g.id = %d",
		$id
	), ARRAY_A );
}

/**
 * Insert or update a group. Role-holder IDs are resolved from WP user display names.
 */
function gp_crm_save_group( $group_id, $name, $bc_name, $gc_name, $ct_name, $ta_name, $timing, $zoom_link, $level, $batch ) {
	global $wpdb;

	$name_to_id = gp_crm_name_to_id();
	$bc_id      = isset( $name_to_id[ $bc_name ] ) ? $name_to_id[ $bc_name ] : null;
	$gc_id      = isset( $name_to_id[ $gc_name ] ) ? $name_to_id[ $gc_name ] : null;
	$ct_id      = isset( $name_to_id[ $ct_name ] ) ? $name_to_id[ $ct_name ] : null;
	$ta_id      = isset( $name_to_id[ $ta_name ] ) ? $name_to_id[ $ta_name ] : null;

	$data = array(
		'name'      => $name,
		'bc_id'     => $bc_id,
		'gc_id'     => $gc_id,
		'ct_id'     => $ct_id,
		'ta_id'     => $ta_id,
		'bc_name'   => '' !== $bc_name ? $bc_name : null,
		'gc_name'   => '' !== $gc_name ? $gc_name : null,
		'ct_name'   => '' !== $ct_name ? $ct_name : null,
		'ta_name'   => '' !== $ta_name ? $ta_name : null,
		'timing'    => '' !== $timing ? $timing : null,
		'zoom_link' => '' !== $zoom_link ? $zoom_link : null,
		'level'     => $level,
		'batch'     => $batch,
	);

	if ( $group_id ) {
		$wpdb->update( $wpdb->prefix . 'gp_groups', $data, array( 'id' => $group_id ) );
	} else {
		$wpdb->insert( $wpdb->prefix . 'gp_groups', $data );
	}
}

/**
 * Delete a group.
 */
function gp_crm_delete_group( $group_id ) {
	global $wpdb;
	$wpdb->delete( $wpdb->prefix . 'gp_groups', array( 'id' => $group_id ) );
}

/**
 * Search sadhaks. Returns array with 'records', 'total'.
 */
function gp_crm_get_sadhaks( $search = '', $group_id = '' ) {
	global $wpdb;

	$where  = array( '1=1' );
	$params = array();

	if ( '' !== $search ) {
		$like   = '%' . $wpdb->esc_like( $search ) . '%';
		$where[] = '(s.name LIKE %s OR s.phone LIKE %s OR s.email LIKE %s OR s.prn LIKE %s)';
		$params[] = $like;
		$params[] = $like;
		$params[] = $like;
		$params[] = $like;
	}
	if ( '' !== $group_id ) {
		$where[]  = 's.group_id = %d';
		$params[] = (int) $group_id;
	}

	$where_sql = implode( ' AND ', $where );

	$select = "SELECT s.id, s.name, s.phone, s.email, s.prn,
	                  COALESCE(NULLIF(g.name,''), '—') AS group_name,
	                  COALESCE(NULLIF(g.level,''), 'Level 1') AS level,
	                  COALESCE(NULLIF(g.batch,''), 'Regular') AS batch,
	                  COALESCE(NULLIF(s.bc_name,''), '—') AS bc_name,
	                  COALESCE(NULLIF(s.gc_name,''), '—') AS gc_name,
	                  COALESCE(NULLIF(s.ct_name,''), '—') AS ct_name,
	                  COALESCE(NULLIF(s.ta_name,''), '—') AS ta_name,
	                  COALESCE(s.created_at, '—') AS created_at,
	                  COALESCE(s.updated_at, '—') AS updated_at,
	                  COALESCE(c.display_name, '—') AS created_by_name,
	                  COALESCE(u.display_name, '—') AS updated_by_name
	           FROM {$wpdb->prefix}gp_sadhak s
	           LEFT JOIN {$wpdb->prefix}gp_groups g ON g.id = s.group_id
	           LEFT JOIN {$wpdb->users} c ON c.ID = s.created_by
	           LEFT JOIN {$wpdb->users} u ON u.ID = s.updated_by
	           WHERE $where_sql
	           ORDER BY s.id DESC";

	$query   = $wpdb->prepare( $select, $params );
	$records = $wpdb->get_results( $query, ARRAY_A );

	$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}gp_sadhak" );

	$out = array();
	foreach ( $records as $r ) {
		$out[] = array(
			'id'               => (int) $r['id'],
			'name'             => $r['name'],
			'phone'            => $r['phone'],
			'email'            => $r['email'],
			'prn'              => $r['prn'],
			'group_name'       => $r['group_name'],
			'level'            => $r['level'],
			'batch'            => $r['batch'],
			'bc_name'          => $r['bc_name'],
			'gc_name'          => $r['gc_name'],
			'ct_name'          => $r['ct_name'],
			'ta_name'          => $r['ta_name'],
			'created_at'       => $r['created_at'],
			'updated_at'       => $r['updated_at'],
			'created_by_name'  => $r['created_by_name'],
			'updated_by_name'  => $r['updated_by_name'],
		);
	}

	return array(
		'records' => $out,
		'total'   => $total,
		'showing' => count( $out ),
	);
}

/**
 * A single sadhak (for editing).
 */
function gp_crm_get_sadhak( $id ) {
	global $wpdb;
	return $wpdb->get_row( $wpdb->prepare(
		"SELECT s.id, s.name, s.phone, s.email, s.prn,
		        COALESCE(g.name, '') AS group_name, s.group_id
		 FROM {$wpdb->prefix}gp_sadhak s
		 LEFT JOIN {$wpdb->prefix}gp_groups g ON g.id = s.group_id
		 WHERE s.id = %d",
		$id
	), ARRAY_A );
}

/**
 * Whether a WP user may edit a specific sadhak (admin or role-holder of its group).
 */
function gp_crm_can_edit_sadhak( $user_id, $sadhak_id ) {
	global $wpdb;

	if ( current_user_can( 'manage_options' ) ) {
		return true;
	}

	$row = $wpdb->get_var( $wpdb->prepare(
		"SELECT s.id
		 FROM {$wpdb->prefix}gp_sadhak s
		 JOIN {$wpdb->prefix}gp_groups g ON g.id = s.group_id
		 WHERE s.id = %d AND (g.bc_id = %d OR g.gc_id = %d OR g.ct_id = %d OR g.ta_id = %d)
		 LIMIT 1",
		$sadhak_id, $user_id, $user_id, $user_id, $user_id
	) );

	return (bool) $row;
}

/**
 * Save (create or update) a sadhak and record history.
 * Returns array( success, code, message, id ) or throws.
 */
function gp_crm_save_sadhak( $user, $data ) {
	global $wpdb;

	$name      = isset( $data['name'] ) ? trim( $data['name'] ) : '';
	$phone     = isset( $data['phone'] ) ? trim( $data['phone'] ) : '';
	$email     = isset( $data['email'] ) ? trim( $data['email'] ) : '';
	$prn       = isset( $data['prn'] ) ? trim( $data['prn'] ) : '';
	$group_id  = ( ! empty( $data['group_id'] ) ) ? (int) $data['group_id'] : null;
	$editing   = ( ! empty( $data['editing_id'] ) ) ? (int) $data['editing_id'] : null;

	if ( '' === $name || '' === $phone ) {
		return array( 'success' => false, 'code' => 400, 'message' => 'Name and Mobile Number are required.' );
	}
	if ( 0 !== strpos( $phone, '+' ) ) {
		$code  = ! empty( $data['country_code'] ) ? $data['country_code'] : '+977';
		$phone = $code . $phone;
	}

	// Duplicate phone check.
	$existing = $wpdb->get_row( $wpdb->prepare(
		"SELECT id, name FROM {$wpdb->prefix}gp_sadhak WHERE phone = %s OR phone = %s LIMIT 1",
		$phone, ltrim( $phone, '+' )
	), ARRAY_A );
	if ( $existing && ! ( $editing && (int) $existing['id'] === $editing ) ) {
		return array( 'success' => false, 'code' => 409, 'message' => "Phone number already registered to '{$existing['name']}'." );
	}

	if ( $editing && ! gp_crm_can_edit_sadhak( $user->ID, $editing ) ) {
		return array( 'success' => false, 'code' => 403, 'message' => 'Access denied. You can only edit sadhaks in your groups.' );
	}

	$bc_name = $gc_name = $ct_name = $ta_name = $group_name = null;
	if ( $group_id ) {
		$info = gp_crm_get_group( $group_id );
		if ( $info ) {
			$bc_name    = $info['bc_name'];
			$gc_name    = $info['gc_name'];
			$ct_name    = $info['ct_name'];
			$ta_name    = $info['ta_name'];
			$group_name = $info['name'];
		}
	}

	$sadhak_data = array(
		'name'      => $name,
		'phone'     => $phone,
		'email'     => '' !== $email ? $email : null,
		'prn'       => '' !== $prn ? $prn : null,
		'group_id'  => $group_id,
		'bc_name'   => $bc_name,
		'gc_name'   => $gc_name,
		'ct_name'   => $ct_name,
		'ta_name'   => $ta_name,
		'updated_by' => $user->ID,
	);

	if ( $editing ) {
		$sadhak_data['updated_at'] = current_time( 'mysql' );
		$wpdb->update( $wpdb->prefix . 'gp_sadhak', $sadhak_data, array( 'id' => $editing ) );
		$sadhak_id = $editing;
	} else {
		$sadhak_data['created_by'] = $user->ID;
		$sadhak_data['created_at'] = current_time( 'mysql' );
		$sadhak_data['updated_at'] = current_time( 'mysql' );
		$wpdb->insert( $wpdb->prefix . 'gp_sadhak', $sadhak_data );
		$sadhak_id = (int) $wpdb->insert_id;
	}

	$wpdb->insert(
		$wpdb->prefix . 'gp_sadhak_history',
		array(
			'sadhak_id'  => $sadhak_id,
			'group_id'   => $group_id,
			'group_name' => $group_name,
			'bc_name'    => $bc_name,
			'gc_name'    => $gc_name,
			'ct_name'    => $ct_name,
			'ta_name'    => $ta_name,
			'changed_by' => $user->ID,
			'changed_at' => current_time( 'mysql' ),
		)
	);

	return array( 'success' => true, 'code' => 200, 'id' => $sadhak_id, 'message' => "Saved: $name" );
}

/**
 * Delete a sadhak.
 */
function gp_crm_delete_sadhak( $id ) {
	global $wpdb;
	$wpdb->delete( $wpdb->prefix . 'gp_sadhak', array( 'id' => $id ) );
}

/**
 * History rows for a sadhak, newest first.
 */
function gp_crm_get_history( $id ) {
	global $wpdb;
	return $wpdb->get_results( $wpdb->prepare(
		"SELECT h.id, COALESCE(NULLIF(h.group_name,''), '—') AS group_name,
		        COALESCE(NULLIF(g.level,''), 'Level 1') AS level,
		        COALESCE(NULLIF(g.batch,''), 'Regular') AS batch,
		        COALESCE(NULLIF(h.bc_name,''), '—') AS bc_name,
		        COALESCE(NULLIF(h.gc_name,''), '—') AS gc_name,
		        COALESCE(NULLIF(h.ct_name,''), '—') AS ct_name,
		        COALESCE(NULLIF(h.ta_name,''), '—') AS ta_name,
		        COALESCE(u.display_name, '—') AS changed_by,
		        h.changed_at
		 FROM {$wpdb->prefix}gp_sadhak_history h
		 LEFT JOIN {$wpdb->prefix}gp_groups g ON g.id = h.group_id
		 LEFT JOIN {$wpdb->users} u ON u.ID = h.changed_by
		 WHERE h.sadhak_id = %d
		 ORDER BY h.changed_at DESC",
		$id
	), ARRAY_A );
}
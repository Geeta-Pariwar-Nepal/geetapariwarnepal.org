<?php
/**
 * REST API endpoints. Namespace: gp_sadhak/v1/api
 * These mirror the standalone app's /api/* routes so the existing
 * dashboard app.js works without modification.
 *
 * @package GP_Sadhak_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'rest_api_init', 'gp_crm_register_routes' );

/**
 * Permission callbacks.
 */
function gp_crm_perm_read() {
	return gp_crm_can_access();
}
function gp_crm_perm_manage() {
	return gp_crm_can_manage();
}

/**
 * Register all REST routes.
 */
function gp_crm_register_routes() {
	$ns = 'gp_sadhak/v1/api';

	register_rest_route( $ns, '/sadhaks', array(
		'methods'             => WP_REST_Server::READABLE,
		'callback'            => 'gp_crm_api_sadhaks',
		'permission_callback' => 'gp_crm_perm_read',
	) );

	register_rest_route( $ns, '/sadhak/(?P<id>\d+)', array(
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'gp_crm_api_get_sadhak',
			'permission_callback' => 'gp_crm_perm_read',
		),
		array(
			'methods'             => WP_REST_Server::DELETABLE,
			'callback'            => 'gp_crm_api_delete_sadhak',
			'permission_callback' => 'gp_crm_perm_manage',
		),
	) );

	register_rest_route( $ns, '/sadhak', array(
		'methods'             => WP_REST_Server::CREATABLE,
		'callback'            => 'gp_crm_api_save_sadhak',
		'permission_callback' => 'gp_crm_perm_read',
	) );

	register_rest_route( $ns, '/sadhak/(?P<id>\d+)/history', array(
		'methods'             => WP_REST_Server::READABLE,
		'callback'            => 'gp_crm_api_sadhak_history',
		'permission_callback' => 'gp_crm_perm_read',
	) );

	register_rest_route( $ns, '/prn/(?P<term>[^/]+)', array(
		'methods'             => WP_REST_Server::READABLE,
		'callback'            => 'gp_crm_api_prn',
		'permission_callback' => 'gp_crm_perm_read',
	) );

	register_rest_route( $ns, '/prn-by-prn/(?P<term>[^/]+)', array(
		'methods'             => WP_REST_Server::READABLE,
		'callback'            => 'gp_crm_api_prn_by_prn',
		'permission_callback' => 'gp_crm_perm_read',
	) );

	register_rest_route( $ns, '/groups', array(
		'methods'             => WP_REST_Server::READABLE,
		'callback'            => 'gp_crm_api_groups',
		'permission_callback' => 'gp_crm_perm_read',
	) );

	register_rest_route( $ns, '/group/(?P<id>\d+)', array(
		array(
			'methods'             => WP_REST_Server::READABLE,
			'callback'            => 'gp_crm_api_get_group',
			'permission_callback' => 'gp_crm_perm_read',
		),
		array(
			'methods'             => WP_REST_Server::DELETABLE,
			'callback'            => 'gp_crm_api_delete_group',
			'permission_callback' => 'gp_crm_perm_manage',
		),
	) );

	register_rest_route( $ns, '/group', array(
		'methods'             => WP_REST_Server::CREATABLE,
		'callback'            => 'gp_crm_api_save_group',
		'permission_callback' => 'gp_crm_perm_manage',
	) );

	register_rest_route( $ns, '/users', array(
		'methods'             => WP_REST_Server::READABLE,
		'callback'            => 'gp_crm_api_users',
		'permission_callback' => 'gp_crm_perm_read',
	) );

	register_rest_route( $ns, '/db-info', array(
		'methods'             => WP_REST_Server::READABLE,
		'callback'            => 'gp_crm_api_db_info',
		'permission_callback' => 'gp_crm_perm_manage',
	) );

	// File-type endpoints are registered on init too (download/upload handled there).
}

/**
 * GET /sadhaks
 */
function gp_crm_api_sadhaks( $request ) {
	return rest_ensure_response( gp_crm_get_sadhaks(
		$request->get_param( 'search' ),
		$request->get_param( 'group_id' )
	) );
}

/**
 * GET /sadhak/{id}
 */
function gp_crm_api_get_sadhak( $request ) {
	$r = gp_crm_get_sadhak( (int) $request['id'] );
	if ( ! $r ) {
		return new WP_Error( 'not_found', 'Not found', array( 'status' => 404 ) );
	}
	return rest_ensure_response( array(
		'id'         => (int) $r['id'],
		'name'       => $r['name'],
		'phone'      => $r['phone'],
		'email'      => $r['email'],
		'prn'        => $r['prn'],
		'group_name' => $r['group_name'],
		'group_id'   => $r['group_id'],
	) );
}

/**
 * DELETE /sadhak/{id}
 */
function gp_crm_api_delete_sadhak( $request ) {
	gp_crm_delete_sadhak( (int) $request['id'] );
	return rest_ensure_response( array( 'success' => true ) );
}

/**
 * POST /sadhak
 */
function gp_crm_api_save_sadhak( $request ) {
	$data = $request->get_json_params();
	if ( ! is_array( $data ) ) {
		$data = $request->get_params();
	}
	$result = gp_crm_save_sadhak( wp_get_current_user(), $data );

	if ( ! $result['success'] ) {
		return new WP_Error( 'save_error', $result['message'], array( 'status' => $result['code'] ) );
	}
	return rest_ensure_response( array(
		'success' => true,
		'id'      => $result['id'],
		'message' => $result['message'],
	) );
}

/**
 * GET /sadhak/{id}/history
 */
function gp_crm_api_sadhak_history( $request ) {
	return rest_ensure_response( gp_crm_get_history( (int) $request['id'] ) );
}

/**
 * GET /prn/{term}
 */
function gp_crm_api_prn( $request ) {
	try {
		return rest_ensure_response( gp_crm_search_prn( $request['term'] ) );
	} catch ( Exception $e ) {
		return new WP_Error( 'prn_error', $e->getMessage(), array( 'status' => 500 ) );
	}
}

/**
 * GET /prn-by-prn/{term}
 */
function gp_crm_api_prn_by_prn( $request ) {
	try {
		return rest_ensure_response( gp_crm_search_by_prn( $request['term'] ) );
	} catch ( Exception $e ) {
		return new WP_Error( 'prn_error', $e->getMessage(), array( 'status' => 500 ) );
	}
}

/**
 * GET /groups
 */
function gp_crm_api_groups() {
	global $wpdb;
	$rows = $wpdb->get_results(
		"SELECT g.id, g.name,
		        COALESCE(NULLIF(g.level,''), 'Level 1') AS level,
		        COALESCE(NULLIF(g.batch,''), 'Regular') AS batch,
		        COALESCE(g.timing, '') AS timing,
		        COALESCE(NULLIF(g.bc_name,''), '—') AS bc_name,
		        COALESCE(NULLIF(g.gc_name,''), '—') AS gc_name,
		        COALESCE(NULLIF(g.ct_name,''), '—') AS ct_name,
		        COALESCE(NULLIF(g.ta_name,''), '—') AS ta_name,
		        COALESCE(g.zoom_link, '') AS zoom_link
		 FROM {$wpdb->prefix}gp_groups g ORDER BY g.name ASC",
		ARRAY_A
	);
	$groups = array();
	foreach ( $rows as $r ) {
		$groups[] = array(
			'id'        => (int) $r['id'],
			'name'      => $r['name'],
			'level'     => $r['level'],
			'batch'     => $r['batch'],
			'timing'    => $r['timing'],
			'bc_name'   => $r['bc_name'],
			'gc_name'   => $r['gc_name'],
			'ct_name'   => $r['ct_name'],
			'ta_name'   => $r['ta_name'],
			'zoom_link' => $r['zoom_link'],
		);
	}
	return rest_ensure_response( $groups );
}

/**
 * GET /group/{id}
 */
function gp_crm_api_get_group( $request ) {
	$info = gp_crm_get_group( (int) $request['id'] );
	if ( ! $info ) {
		return new WP_Error( 'not_found', 'Not found', array( 'status' => 404 ) );
	}
	return rest_ensure_response( array(
		'id'        => (int) $info['id'],
		'name'      => $info['name'],
		'level'     => $info['level'],
		'batch'     => $info['batch'],
		'bc_name'   => $info['bc_name'],
		'gc_name'   => $info['gc_name'],
		'ct_name'   => $info['ct_name'],
		'ta_name'   => $info['ta_name'],
		'timing'    => $info['timing'],
		'zoom_link' => $info['zoom_link'],
	) );
}

/**
 * POST /group
 */
function gp_crm_api_save_group( $request ) {
	$data = $request->get_json_params();
	if ( ! is_array( $data ) ) {
		$data = $request->get_params();
	}
	$name = isset( $data['name'] ) ? trim( $data['name'] ) : '';
	if ( '' === $name ) {
		return new WP_Error( 'invalid', 'Group name is required.', array( 'status' => 400 ) );
	}
	try {
		gp_crm_save_group(
			! empty( $data['id'] ) ? (int) $data['id'] : null,
			$name,
			isset( $data['bc_name'] ) ? trim( $data['bc_name'] ) : '',
			isset( $data['gc_name'] ) ? trim( $data['gc_name'] ) : '',
			isset( $data['ct_name'] ) ? trim( $data['ct_name'] ) : '',
			isset( $data['ta_name'] ) ? trim( $data['ta_name'] ) : '',
			isset( $data['timing'] ) ? trim( $data['timing'] ) : '',
			isset( $data['zoom_link'] ) ? trim( $data['zoom_link'] ) : '',
			isset( $data['level'] ) ? trim( $data['level'] ) : 'Level 1',
			isset( $data['batch'] ) ? trim( $data['batch'] ) : 'Regular'
		);
		return rest_ensure_response( array( 'success' => true ) );
	} catch ( Exception $e ) {
		return new WP_Error( 'group_error', $e->getMessage(), array( 'status' => 500 ) );
	}
}

/**
 * DELETE /group/{id}
 */
function gp_crm_api_delete_group( $request ) {
	try {
		gp_crm_delete_group( (int) $request['id'] );
		return rest_ensure_response( array( 'success' => true ) );
	} catch ( Exception $e ) {
		return new WP_Error( 'group_error', $e->getMessage(), array( 'status' => 500 ) );
	}
}

/**
 * GET /users — display names for the datalist.
 */
function gp_crm_api_users() {
	return rest_ensure_response( gp_crm_user_names() );
}

/**
 * GET /db-info — counts (admin only).
 */
function gp_crm_api_db_info() {
	global $wpdb;
	return rest_ensure_response( array(
		'prefix'    => $wpdb->prefix,
		'sadhaks'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}gp_sadhak" ),
		'groups'    => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}gp_groups" ),
		'history'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}gp_sadhak_history" ),
		'rest_base' => rest_url( 'gp_sadhak/v1' ),
	) );
}

/**
 * File endpoints (download + upload) need raw output, so they are separate.
 */
add_action( 'rest_api_init', 'gp_crm_register_file_routes', 99 );
function gp_crm_register_file_routes() {
	$ns = 'gp_sadhak/v1/api';

	register_rest_route( $ns, '/backup/download', array(
		'methods'             => WP_REST_Server::READABLE,
		'callback'            => 'gp_crm_api_download',
		'permission_callback' => 'gp_crm_perm_manage',
	) );

	register_rest_route( $ns, '/backup/upload', array(
		'methods'             => WP_REST_Server::CREATABLE,
		'callback'            => 'gp_crm_api_upload',
		'permission_callback' => 'gp_crm_perm_manage',
	) );
}

/**
 * Download the data as an SQL-exportable snapshot (CSV-ish via wp_snapshot? Use JSON lines).
 * Returns glabels — in MySQL we export via a JSON bundle the user can re-import.
 */
function gp_crm_api_download() {
	global $wpdb;
	$prefix = $wpdb->prefix;

	$bundle = array(
		'groups'  => $wpdb->get_results( "SELECT * FROM {$prefix}gp_groups", ARRAY_A ),
		'sadhaks' => $wpdb->get_results( "SELECT * FROM {$prefix}gp_sadhak", ARRAY_A ),
		'history' => $wpdb->get_results( "SELECT * FROM {$prefix}gp_sadhak_history", ARRAY_A ),
	);

	header( 'Content-Type: application/json' );
	header( 'Content-Disposition: attachment; filename="gp-sadhak-crm-export.json"' );
	echo wp_json_encode( $bundle, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
	exit;
}

/**
 * Restore from an uploaded JSON snapshot produced by the download endpoint.
 */
function gp_crm_api_upload() {
	global $wpdb;
	$prefix = $wpdb->prefix;

	if ( empty( $_FILES['file'] ) || UPLOAD_ERR_OK !== $_FILES['file']['error'] || empty( $_FILES['file']['tmp_name'] ) ) {
		return new WP_Error( 'upload', 'No file provided.', array( 'status' => 400 ) );
	}

	$name = $_FILES['file']['name'];
	if ( '' === $name || '.json' !== strtolower( substr( $name, -5 ) ) ) {
		return new WP_Error( 'upload', 'File must be a .json snapshot.', array( 'status' => 400 ) );
	}

	$raw  = file_get_contents( $_FILES['file']['tmp_name'] );
	$data = json_decode( $raw, true );
	if ( ! is_array( $data ) || ! isset( $data['sadhaks'], $data['groups'], $data['history'] ) ) {
		return new WP_Error( 'upload', 'Invalid snapshot file.', array( 'status' => 400 ) );
	}

	$wpdb->query( "DELETE FROM {$prefix}gp_sadhak_history" );
	$wpdb->query( "DELETE FROM {$prefix}gp_sadhak" );
	$wpdb->query( "DELETE FROM {$prefix}gp_groups" );

	foreach ( $data['groups'] as $row ) {
		$row['level'] = isset( $row['level'] ) ? $row['level'] : 'Level 1';
		$row['batch'] = isset( $row['batch'] ) ? $row['batch'] : 'Regular';
		$wpdb->insert( $prefix . 'gp_groups', $row );
	}
	foreach ( $data['sadhaks'] as $row ) {
		if ( ! isset( $row['created_at'] ) ) {
			$row['created_at'] = current_time( 'mysql' );
		}
		if ( ! isset( $row['updated_at'] ) ) {
			$row['updated_at'] = current_time( 'mysql' );
		}
		$wpdb->insert( $prefix . 'gp_sadhak', $row );
	}
	foreach ( $data['history'] as $row ) {
		$wpdb->insert( $prefix . 'gp_sadhak_history', $row );
	}

	return rest_ensure_response( array( 'success' => true, 'message' => 'Database restored successfully.' ) );
}
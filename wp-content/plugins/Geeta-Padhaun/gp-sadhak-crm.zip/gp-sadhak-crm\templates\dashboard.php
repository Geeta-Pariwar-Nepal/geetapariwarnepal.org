<?php
/**
 * CRM dashboard UI. Included by the [gp_sadhak_crm] shortcode.
 *
 * @package GP_Sadhak_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $COUNTRY_CODES, $COUNTRY_NAMES;

$crm_user    = wp_get_current_user();
$full_name   = $crm_user ? $crm_user->display_name : '';
$is_manager  = gp_crm_can_manage();
$role_label  = $is_manager ? 'Admin' : 'User';
$groups      = gp_crm_get_groups();
$users_combo = gp_crm_user_names();
$default_code = '+977';
$api_base    = rest_url( 'gp_sadhak/v1' );
$logout_url  = wp_logout_url( home_url() );
?>
<div class="app-container">
    <header class="top-bar">
        <div class="top-bar-left">
            <h2>Welcome, <?php echo esc_html( $full_name ); ?></h2>
        </div>
        <div class="top-bar-right">
            <span class="badge"><?php echo esc_html( $role_label ); ?></span>
            <?php if ( $is_manager ) : ?>
            <button class="btn btn-secondary" id="manageGroupsBtn">Manage Groups</button>
            <a href="<?php echo esc_url( $api_base . '/api/backup/download' ); ?>" class="btn btn-info">Download Snapshot</a>
            <button class="btn btn-warning" id="uploadDbBtn">Upload Snapshot</button>
            <?php endif; ?>
            <a href="<?php echo esc_url( $logout_url ); ?>" class="btn btn-danger">Logout</a>
        </div>
    </header>
    <div class="main-content">
        <section class="panel" id="registrationPanel">
            <h3 class="panel-title">Register / Edit Sadhak</h3>
            <form id="sadhakForm" novalidate>
                <input type="hidden" id="editingId" value="">
                <input type="hidden" id="countryCode" value="<?php echo esc_attr( $default_code ); ?>">

                <div class="form-group">
                    <label for="name">Full Name *</label>
                    <input type="text" id="name" required>
                </div>

                <div class="form-group">
                    <label for="phone">Mobile Number *</label>
                    <div class="phone-row">
                        <select id="countryCodeSelect">
                            <?php foreach ( $COUNTRY_CODES as $code ) : ?>
                            <option value="<?php echo esc_attr( $code ); ?>" <?php selected( $code, $default_code ); ?>><?php echo esc_html( $code ); ?> <?php echo esc_html( isset( $COUNTRY_NAMES[ $code ] ) ? $COUNTRY_NAMES[ $code ] : '' ); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="text" id="phone" required>
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email">
                </div>

                <div class="form-group">
                    <label for="prn">PRN (auto-searched)</label>
                    <input type="text" id="prn">
                </div>

                <div class="form-group">
                    <label for="groupSelect">Group</label>
                    <div style="display:flex;gap:6px;align-items:center">
                        <select id="groupSelect" style="flex:1">
                            <option value="">-- Select --</option>
                            <?php foreach ( $groups as $g ) : ?>
                            <option value="<?php echo (int) $g['id']; ?>" data-level="<?php echo esc_attr( $g['level'] ); ?>" data-batch="<?php echo esc_attr( $g['batch'] ); ?>"><?php echo esc_html( $g['name'] ); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <span id="levelDisplay" class="badge" style="display:none"></span>
                        <span id="batchDisplay" class="badge" style="display:none"></span>
                    </div>
                </div>

                <div id="roleHolderDisplay">
                    <p><strong>BC:</strong> <span id="bcDisplay">—</span></p>
                    <p><strong>GC:</strong> <span id="gcDisplay">—</span></p>
                    <p><strong>CT:</strong> <span id="ctDisplay">—</span></p>
                    <p><strong>TA:</strong> <span id="taDisplay">—</span></p>
                </div>

                <div id="zoomLinkRow" style="display:none">
                    <a href="#" id="zoomLink" target="_blank" class="btn btn-success btn-sm">Open Zoom</a>
                </div>

                <div id="formStatus" class="status-text">Ready</div>

                <div class="btn-row">
                    <button type="submit" class="btn btn-success" id="saveBtn">Save Sadhak</button>
                    <button type="button" class="btn btn-secondary" id="clearBtn">Cancel</button>
                </div>
            </form>
        </section>

        <section class="panel" id="listPanel">
            <h3 class="panel-title">Saved Sadhak Records</h3>

            <div class="filter-bar">
                <input type="text" id="searchInput" placeholder="Search name, phone, email, PRN...">
                <select id="filterGroup">
                    <option value="">All Groups</option>
                    <?php foreach ( $groups as $g ) : ?>
                    <option value="<?php echo (int) $g['id']; ?>" data-level="<?php echo esc_attr( $g['level'] ); ?>"><?php echo esc_html( $g['name'] ); ?></option>
                    <?php endforeach; ?>
                </select>
                <button class="btn btn-secondary btn-sm" id="clearFilterBtn">Clear</button>
            </div>

            <div class="toolbar">
                <span id="totalLabel"></span>
                <div class="toolbar-actions">
                    <button class="btn btn-info btn-sm" id="editBtn">Edit</button>
                    <button class="btn btn-success btn-sm" id="whatsappBtn">WhatsApp</button>
                    <button class="btn btn-secondary btn-sm" id="historyBtn">History</button>
                    <button class="btn btn-danger btn-sm" id="deleteBtn">Delete</button>
                    <button class="btn btn-secondary btn-sm" id="refreshBtn">Refresh</button>
                </div>
            </div>

            <div class="table-wrapper">
                <table id="sadhakTable">
                    <thead>
                        <tr>
                            <th>Name</th><th>Phone</th><th>Email</th><th>PRN</th>
                            <th>Group</th><th>Level</th><th>Batch</th>
                            <th>BC</th><th>GC</th><th>CT</th><th>TA</th>
                            <th>Created</th><th>Updated</th><th>Created By</th><th>Updated By</th>
                        </tr>
                    </thead>
                    <tbody id="sadhakTableBody"></tbody>
                </table>
            </div>
        </section>
    </div>
</div>

<div class="modal-overlay" id="groupModal">
    <div class="modal">
        <div class="modal-header">
            <h3>Manage Groups / Levels</h3>
            <button class="modal-close" id="groupModalClose">&times;</button>
        </div>
        <div class="modal-body">
            <div class="table-wrapper">
                <table id="groupTable">
                    <thead>
                        <tr>
                            <th>Group</th><th>Level</th><th>Batch</th><th>Timing</th>
                            <th>BC</th><th>GC</th><th>CT</th><th>TA</th><th>Zoom</th>
                        </tr>
                    </thead>
                    <tbody id="groupTableBody"></tbody>
                </table>
            </div>
            <div class="btn-row">
                <button class="btn btn-primary btn-sm" id="addGroupBtn">Add Group</button>
                <button class="btn btn-info btn-sm" id="editGroupBtn">Edit</button>
                <button class="btn btn-danger btn-sm" id="deleteGroupBtn">Delete</button>
                <button class="btn btn-success btn-sm" id="openGroupZoomBtn">Open Zoom</button>
            </div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="groupEditModal">
    <div class="modal modal-sm">
        <div class="modal-header">
            <h3 id="groupEditTitle">New Group</h3>
            <button class="modal-close" id="groupEditModalClose">&times;</button>
        </div>
        <div class="modal-body">
            <form id="groupForm">
                <input type="hidden" id="groupEditId" value="">
                <div class="form-group">
                    <label for="groupName">Group Name *</label>
                    <input type="text" id="groupName" required>
                </div>
                <div class="form-group">
                    <label for="groupLevel">Level</label>
                    <select id="groupLevel">
                        <option value="Level 1">Level 1</option>
                        <option value="Level 2">Level 2</option>
                        <option value="Level 3">Level 3</option>
                        <option value="Level 4">Level 4</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="groupBatch">Batch</label>
                    <select id="groupBatch">
                        <option value="Regular">Regular</option>
                        <option value="Kids">Kids</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="groupBc">BC (Batch Coordinator)</label>
                    <input type="text" id="groupBc" list="userList">
                </div>
                <div class="form-group">
                    <label for="groupGc">GC (Group Coordinator)</label>
                    <input type="text" id="groupGc" list="userList">
                </div>
                <div class="form-group">
                    <label for="groupCt">CT (Co-Teacher)</label>
                    <input type="text" id="groupCt" list="userList">
                </div>
                <div class="form-group">
                    <label for="groupTa">TA (Teaching Assistant)</label>
                    <input type="text" id="groupTa" list="userList">
                </div>
                <div class="form-group">
                    <label for="groupTiming">Class Timing</label>
                    <input type="text" id="groupTiming">
                </div>
                <div class="form-group">
                    <label for="groupZoom">Zoom Meeting Link</label>
                    <input type="url" id="groupZoom">
                </div>
                <datalist id="userList">
                    <?php foreach ( $users_combo as $u ) : ?>
                    <option value="<?php echo esc_attr( $u ); ?>">
                    <?php endforeach; ?>
                </datalist>
                <button type="submit" class="btn btn-primary btn-block">Save Group</button>
            </form>
        </div>
    </div>
</div>

<div class="modal-overlay" id="historyModal">
    <div class="modal">
        <div class="modal-header">
            <h3 id="historyModalTitle">History</h3>
            <button class="modal-close" id="historyModalClose">&times;</button>
        </div>
        <div class="modal-body">
            <div class="table-wrapper">
                <table id="historyTable">
                    <thead>
                        <tr>
                            <th>#</th><th>Group</th><th>Level</th><th>Batch</th>
                            <th>BC</th><th>GC</th><th>CT</th><th>TA</th>
                            <th>Changed By</th><th>Date</th>
                        </tr>
                    </thead>
                    <tbody id="historyTableBody"></tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div class="modal-overlay" id="uploadDbModal">
    <div class="modal modal-sm">
        <div class="modal-header">
            <h3>Restore Database</h3>
            <button class="modal-close" id="uploadDbModalClose">&times;</button>
        </div>
        <div class="modal-body">
            <p style="margin-bottom:12px;color:#666">Upload a <code>.json</code> snapshot file (downloaded via <em>Download Snapshot</em>). The current data will be replaced.</p>
            <input type="file" id="dbFileInput" accept=".json" style="display:block;margin-bottom:12px">
            <div id="uploadStatus" class="status-text"></div>
            <button class="btn btn-primary btn-block" id="uploadDbConfirm">Upload & Restore</button>
        </div>
    </div>
</div>

<script>
(function() {
    var base = window.APP_BASE || '';
    var btn = document.getElementById('uploadDbBtn');
    var modal = document.getElementById('uploadDbModal');
    if (!btn || !modal) return;
    btn.addEventListener('click', function() { modal.classList.add('active'); });
    var closeBtn = document.getElementById('uploadDbModalClose');
    if (closeBtn) {
        closeBtn.addEventListener('click', function() { modal.classList.remove('active'); });
    }
    var confirmBtn = document.getElementById('uploadDbConfirm');
    var fileInput = document.getElementById('dbFileInput');
    var status = document.getElementById('uploadStatus');
    if (!confirmBtn || !fileInput || !status) return;
    confirmBtn.addEventListener('click', async function() {
        if (!fileInput.files.length) {
            status.textContent = 'Please select a snapshot file.';
            status.style.color = 'red';
            return;
        }
        var file = fileInput.files[0];
        if (!file.name.toLowerCase().endsWith('.json')) {
            status.textContent = 'File must be a .json snapshot.';
            status.style.color = 'red';
            return;
        }
        var formData = new FormData();
        formData.append('file', file);
        status.textContent = 'Uploading...';
        status.style.color = '#666';
        try {
            var res = await fetch(base + '/api/backup/upload', { method: 'POST', body: formData, credentials: 'same-origin' });
            var data = await res.json();
            if (data.success) {
                status.textContent = 'Database restored! Reloading...';
                status.style.color = 'green';
                setTimeout(function() { location.reload(); }, 1500);
            } else {
                status.textContent = 'Error: ' + (data.error || 'Unknown error');
                status.style.color = 'red';
            }
        } catch (err) {
            status.textContent = 'Network error: ' + err.message;
            status.style.color = 'red';
        }
    });
})();
</script>
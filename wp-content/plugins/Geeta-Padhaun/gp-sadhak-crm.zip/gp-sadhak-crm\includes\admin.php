<?php
/**
 * Admin page: import crm.db, manage user access, show info.
 *
 * @package GP_Sadhak_CRM
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', 'gp_crm_admin_menu' );
function gp_crm_admin_menu() {
	add_menu_page(
		'GP Sadhak CRM',
		'GP Sadhak CRM',
		'manage_options',
		'gp-sadhak-crm',
		'gp_crm_admin_page',
		'dashicons-groups',
		25
	);
}

/**
 * Route the admin page tabs.
 */
function gp_crm_admin_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( 'Not allowed' );
	}

	$tab = isset( $_GET['tab'] ) ? sanitize_key( $_GET['tab'] ) : 'import';

	echo '<div class="wrap"><h1>GP Sadhak CRM</h1>';

	echo '<nav class="nav-tab-wrapper">';
	$tabs = array(
		'import' => 'Import Data',
		'access' => 'User Access',
		'info'   => 'Info',
	);
	foreach ( $tabs as $key => $label ) {
		$active = ( $tab === $key ) ? ' nav-tab-active' : '';
		echo '<a class="nav-tab' . $active . '" href="?page=gp-sadhak-crm&tab=' . $key . '">' . esc_html( $label ) . '</a>';
	}
	echo '</nav><div style="margin-top:16px">';

	if ( 'import' === $tab ) {
		gp_crm_admin_import_tab();
	} elseif ( 'access' === $tab ) {
		gp_crm_admin_access_tab();
	} else {
		gp_crm_admin_info_tab();
	}

	echo '</div></div>';
}

/**
 * Import tab: upload the old crm.db.
 */
function gp_crm_admin_import_tab() {
	$message = '';
	$error   = '';

	if ( isset( $_POST['gp_crm_import'] ) && check_admin_referer( 'gp_crm_import' ) ) {
		if ( empty( $_FILES['crm_db'] ) || UPLOAD_ERR_OK !== $_FILES['crm_db']['error'] ) {
			$error = 'Please choose a crm.db file.';
		} else {
			$create_users = ! empty( $_POST['create_users'] );
			$result       = gp_crm_import_from_sqlite( $_FILES['crm_db']['tmp_name'], $create_users, get_current_user_id() );
			if ( ! empty( $result['success'] ) ) {
				$message = $result['message'];
			} else {
				$error = isset( $result['error'] ) ? $result['error'] : 'Import failed.';
			}
		}
	}

	if ( $message ) {
		echo '<div class="notice notice-success"><p>' . esc_html( $message ) . '</p></div>';
	}
	if ( $error ) {
		echo '<div class="notice notice-error"><p>' . esc_html( $error ) . '</p></div>';
	}
	?>
	<h2>Import your existing crm.db</h2>
	<p>Upload the <code>crm.db</code> file from your current app (the standalone app's <code>data/</code> folder, or download it with its <em>Download DB</em> button). Its sadhaks, groups and history will be copied into WordPress tables. Existing CRM data is replaced.</p>

	<?php if ( ! gp_crm_sqlite_available() ) : ?>
		<div class="notice notice-warning"><p>Your server does not have the PHP <strong>pdo_sqlite</strong> extension, so the .db import cannot run. Ask your host to enable <code>pdo_sqlite</code>, or use the <a href="?page=gp-sadhak-crm&tab=info">Info tab</a> to export a JSON snapshot from another copy.</p></div>
	<?php else : ?>
		<form method="post" enctype="multipart/form-data">
			<?php wp_nonce_field( 'gp_crm_import' ); ?>
			<table class="form-table">
				<tr>
					<th><label for="crm_db">crm.db file</label></th>
					<td><input type="file" name="crm_db" id="crm_db" accept=".db"></td>
				</tr>
				<tr>
					<th>Create WordPress users</th>
					<td>
						<label>
							<input type="checkbox" name="create_users" value="1" checked>
							Create a WordPress account for each CRM staff user (BC/GC/CT/TA), with a random password, and give them CRM access.
						</label>
					</td>
				</tr>
			</table>
			<p class="submit"><button type="submit" name="gp_crm_import" class="button button-primary">Import crm.db</button></p>
		</form>
	<?php endif; ?>
	<?php
}

/**
 * Access tab: grant/revoke CRM access per user.
 */
function gp_crm_admin_access_tab() {
	if ( isset( $_POST['gp_crm_access'] ) && check_admin_referer( 'gp_crm_access' ) ) {
		$users = get_users( array( 'fields' => 'ID' ) );
		foreach ( $users as $uid ) {
			$access = ! empty( $_POST['access'][ $uid ] );
			$manage = ! empty( $_POST['manage'][ $uid ] );
			gp_crm_set_user_access( $uid, $access, $manage );
		}
		echo '<div class="notice notice-success"><p>Access updated.</p></div>';
	}
	?>
	<h2>CRM User Access</h2>
	<p>Choose which WordPress users can use the CRM. Administrators always have full access.</p>
	<form method="post">
		<?php wp_nonce_field( 'gp_crm_access' ); ?>
		<table class="widefat striped" style="max-width:700px">
			<thead>
				<tr>
					<th>User</th>
					<th>Role</th>
					<th>CRM access</th>
					<th>CRM manager</th>
				</tr>
			</thead>
			<tbody>
			<?php
			$users = get_users( array( 'orderby' => 'display_name', 'order' => 'ASC' ) );
			foreach ( $users as $u ) :
				$is_admin = user_can( $u, 'manage_options' );
				$access   = $is_admin || user_can( $u, 'gp_access_sadhak' );
				$manage   = $is_admin || user_can( $u, 'gp_manage_sadhak' );
				?>
				<tr>
					<td><?php echo esc_html( $u->display_name ); ?> <code>(<?php echo esc_html( $u->user_login ); ?>)</code></td>
					<td><?php echo esc_html( implode( ', ', $u->roles ) ); ?></td>
					<td><input type="checkbox" name="access[<?php echo (int) $u->ID; ?>]" value="1" <?php checked( $access ); ?> <?php disabled( $is_admin ); ?>></td>
					<td><input type="checkbox" name="manage[<?php echo (int) $u->ID; ?>]" value="1" <?php checked( $manage ); ?> <?php disabled( $is_admin ); ?>></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="submit"><button type="submit" name="gp_crm_access" class="button button-primary">Save Access</button></p>
	</form>
	<?php
}

/**
 * Info tab: counts + usage.
 */
function gp_crm_admin_info_tab() {
	global $wpdb;
	$counts = array(
		'Sadhaks' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}gp_sadhak" ),
		'Groups'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}gp_groups" ),
		'History' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}gp_sadhak_history" ),
	);
	?>
	<h2>Usage</h2>
	<p>Put the shortcode <code>[gp_sadhak_crm]</code> on any page (e.g. an Astra page) to show the CRM.</p>
	<table class="widefat striped" style="max-width:500px">
		<?php foreach ( $counts as $label => $n ) : ?>
			<tr><th><?php echo esc_html( $label ); ?></th><td><?php echo esc_html( $n ); ?></td></tr>
		<?php endforeach; ?>
		<tr><th>REST base</th><td><code><?php echo esc_html( rest_url( 'gp_sadhak/v1/api' ) ); ?></code></td></tr>
		<tr><th>SQLite available</th><td><?php echo gp_crm_sqlite_available() ? 'Yes' : 'No'; ?></td></tr>
	</table>
	<?php
}